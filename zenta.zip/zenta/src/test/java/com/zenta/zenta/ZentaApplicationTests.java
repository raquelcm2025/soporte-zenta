package com.zenta.zenta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZentaApplicationTests {

	@Test
	void contextLoads() {
	}

}
