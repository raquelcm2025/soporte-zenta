package com.zenta.zenta.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zenta.zenta.entity.Rol;

public interface RolRepository extends JpaRepository<Rol, Integer> {

}
