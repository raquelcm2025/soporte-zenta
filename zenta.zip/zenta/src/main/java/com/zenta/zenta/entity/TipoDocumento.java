package com.zenta.zenta.entity;

public enum TipoDocumento {
    DNI,
    CARNET_DE_EXTRANJERIA,
    PASAPORTE
}
