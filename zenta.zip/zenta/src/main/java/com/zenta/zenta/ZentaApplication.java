package com.zenta.zenta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZentaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZentaApplication.class, args);
	}

}
