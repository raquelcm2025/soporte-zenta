package com.zenta.zenta.controller;

import org.springframework.security.core.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.ui.Model;

import com.zenta.zenta.entity.SecurityUser;
import com.zenta.zenta.repository.UserRepository;


@Controller
public class PerfilController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/editarperfiles")
    public String mostrarPerfil(Model model, Authentication authentication) {
        SecurityUser securityUser = (SecurityUser) authentication.getPrincipal();
        com.zenta.zenta.entity.User user = securityUser.getUser();

        model.addAttribute("usuario", user);
        return "editarperfiles";
    }

    @PostMapping("/editarperfiles")
    public String actualizarPerfil(@ModelAttribute("usuario") com.zenta.zenta.entity.User formUser,
                                   Authentication authentication) {

        SecurityUser securityUser = (SecurityUser) authentication.getPrincipal();
        com.zenta.zenta.entity.User actualUser = securityUser.getUser();

        // Solo actualiza los campos permitidos
        actualUser.setNombre(formUser.getNombre());
        actualUser.setApellido(formUser.getApellido());

        userRepository.save(actualUser);

        return "redirect:/editarperfiles?success";
    }
}